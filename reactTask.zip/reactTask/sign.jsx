import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route, Link, browserHistory, IndexRoute  } from 'react-router'


class Sign extends React.Component {
	constructor(props,context) {
		super(props,context);
		this.context=context;
	}
	updated(){
		console.log(ReactDOM.findDOMNode(this.refs.named).value);
		if(ReactDOM.findDOMNode(this.refs.named).value!="")
		{
			console.log(ReactDOM.findDOMNode(this.refs.named).value);
			browserHistory.push('home');

		}
		else
		{
			console.log('please provide any details');
		}
	}
   render() {
      return (
         <div>
         	name<input type="text" ref="named"/>
         	password<input type="text"/>
         	<button onClick={this.updated.bind(this)}>login</button>
         	{/*<button><Link to="home">login</Link></button>*/}
         </div>
      )
   }
}

export default Sign;