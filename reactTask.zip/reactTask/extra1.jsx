import React from 'react';
import ReactDOM from 'react-dom';

class App extends React.Component {

   constructor(props) {
      super(props);
		
      this.state = {
         data: ''
      }

      this.updateState = this.updateState.bind(this);
      this.clearInput = this.clearInput.bind(this);
   };

   updateState(e) {
       this.setState({data: e.target.value});
   }

   clearInput() {
   	console.log(ReactDOM.findDOMNode(this.refs.myInput).value);
     
      ReactDOM.findDOMNode(this.refs.myInput).focus();
     this.setState({data: ''});
   }

   render() {
      return (
         <div>
            <input onChange = {this.updateState} 
               ref = "myInput"></input>
            <button onClick = {this.clearInput}>CLEAR</button>
            <h4>{this.state.data}</h4>
         </div>
      );
   }
}

export default App;