import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route, Link, browserHistory, IndexRoute  } from 'react-router'


class Home extends React.Component {
   render() {
      return (
         <div>
         	<button><Link to="sign">Logout</Link></button>
         </div>
      )
   }
}

export default Home;